<?php

if (!defined('ABSPATH')) exit;

function ai_log_event($message) {
    $logs = get_option('ai_simple_logs', []);
    if (!is_array($logs)) $logs = [];
    $logs[] = [
        'time' => current_time('mysql'),
        'user_id' => get_current_user_id(),
        'event' => $message
    ];
    update_option('ai_simple_logs', $logs);
}

function ai_log_conversation($user_id, $prompt, $reply) {
    $logs = get_option('ai_simple_logs', []);
    if (!is_array($logs)) $logs = [];
    $logs[] = [
        'time' => current_time('mysql'),
        'user_id' => $user_id,
        'prompt' => $prompt,
        'reply' => $reply
    ];
    update_option('ai_simple_logs', $logs);
}

/**
 * Executes a full request prepared by the Assistant.
 * Automatically adds WooCommerce authentication headers.
 */
function ai_execute_full_request($json) {
    $data = json_decode($json, true);
    if (!$data || !isset($data['action']) || $data['action'] !== 'woocommerce_request') {
        return null;
    }

    $req = $data['request'];

    // 🔑 Inject authentication headers
    $ck = get_option('ai_wc_consumer_key');
    $cs = get_option('ai_wc_consumer_secret');
    $auth_header = 'Basic ' . base64_encode("$ck:$cs");

    $headers = isset($req['headers']) && is_array($req['headers']) ? $req['headers'] : [];
    $headers['Authorization'] = $auth_header;

    $args = [
        'method'  => $req['method'],
        'headers' => $headers,
        'body'    => !empty($req['body']) ? json_encode($req['body']) : null
    ];

    $response = wp_remote_request($req['url'], $args);

    return [
        'status' => wp_remote_retrieve_response_code($response),
        'body'   => json_decode(wp_remote_retrieve_body($response), true)
    ];
}

/**
 * Sends initial context and API details to the Assistant
 */
function ai_send_context_with_instructions($thread_id, $api_key, $assistant_id) {
    $today = date("Y-m-d");
    $wc_url = get_option('ai_wc_api_url', '');

    $message = "Today is {$today}. Use this date to calculate 'tomorrow' or 'after tomorrow'.\n\n" .
               "WooCommerce API Base URL:\n" .
               "- {$wc_url}\n\n" .
               "📦 Orders:\n" .
               "- List orders: GET {base_url}/wc/v3/orders\n" .
               "- Create order: POST {base_url}/wc/v3/orders\n" .
               "- Delete order: DELETE {base_url}/wc/v3/orders/{id}\n\n" .
               "📅 Bookings:\n" .
               "- List bookings: GET {base_url}/wc-bookings/v1/bookings\n" .
               "- Create booking: POST {base_url}/wc-bookings/v1/bookings\n" .
               "- Delete booking: DELETE {base_url}/wc-bookings/v1/bookings/{id}\n\n" .
               "🛒 Products:\n" .
               "- List products: GET {base_url}/wc/v3/products\n" .
               "- Get product details: GET {base_url}/wc/v3/products/{id}\n" .
               "- Delete product: DELETE {base_url}/wc/v3/products/{id}\n\n" .
               "⚠️ Remember:\n" .
               "- For bookings, ALWAYS use `/wc-bookings/v1/bookings`.\n" .
               "- For orders, ALWAYS use `/wc/v3/orders`.\n" .
               "- For products, ALWAYS use `/wc/v3/products`.\n";

    wp_remote_post("https://api.openai.com/v1/threads/$thread_id/messages", [
        'headers' => [
            'Authorization' => "Bearer $api_key",
            'Content-Type'  => 'application/json',
            'OpenAI-Beta'   => 'assistants=v2'
        ],
        'body' => json_encode([
            "role" => "user",
            "content" => $message
        ])
    ]);

    ai_log_event("♻️ Context with API details sent");
}

/**
 * Handles sending tasks to the Assistant
 */
function ai_simple_run_task($task, $api_key, $assistant_id) {
    $user_id = get_current_user_id();
    $thread_option = 'ai_simple_thread_id_' . $user_id;
    $thread_id = get_option($thread_option);

    // ✅ Create thread if not exists
    if (!$thread_id) {
        $resp = wp_remote_post("https://api.openai.com/v1/threads", [
            'headers' => [
                'Authorization' => "Bearer $api_key",
                'Content-Type'  => 'application/json',
                'OpenAI-Beta'   => 'assistants=v2'
            ]
        ]);

        $data = json_decode(wp_remote_retrieve_body($resp), true);
        if (!empty($data['id'])) {
            $thread_id = $data['id'];
            update_option($thread_option, $thread_id);
            ai_log_event("🆕 New thread created");
            ai_send_context_with_instructions($thread_id, $api_key, $assistant_id);
        } else {
            return "❌ Error creating thread: " . json_encode($data);
        }
    }

    // ✅ Send user message
    wp_remote_post("https://api.openai.com/v1/threads/$thread_id/messages", [
        'headers' => [
            'Authorization' => "Bearer $api_key",
            'Content-Type'  => 'application/json',
            'OpenAI-Beta'   => 'assistants=v2'
        ],
        'body' => json_encode([
            "role" => "user",
            "content" => $task
        ])
    ]);

    // ✅ Start run
    $run_resp = wp_remote_post("https://api.openai.com/v1/threads/$thread_id/runs", [
        'headers' => [
            'Authorization' => "Bearer $api_key",
            'Content-Type'  => 'application/json',
            'OpenAI-Beta'   => 'assistants=v2'
        ],
        'body' => json_encode([
            "assistant_id" => $assistant_id
        ])
    ]);

    $run_data = json_decode(wp_remote_retrieve_body($run_resp), true);
    if (empty($run_data['id'])) {
        return "❌ Error starting run: " . json_encode($run_data);
    }

    $run_id = $run_data['id'];

    // ✅ Poll until run completes
    for ($i = 0; $i < 10; $i++) {
        sleep(1);
        $check = wp_remote_get("https://api.openai.com/v1/threads/$thread_id/runs/$run_id", [
            'headers' => [
                'Authorization' => "Bearer $api_key",
                'OpenAI-Beta'   => 'assistants=v2'
            ]
        ]);
        $check_data = json_decode(wp_remote_retrieve_body($check), true);
        if (!empty($check_data['status']) && $check_data['status'] === 'completed') break;
    }

    // ✅ Get latest messages
    $msg_resp = wp_remote_get("https://api.openai.com/v1/threads/$thread_id/messages", [
        'headers' => [
            'Authorization' => "Bearer $api_key",
            'OpenAI-Beta'   => 'assistants=v2'
        ]
    ]);

    $messages = json_decode(wp_remote_retrieve_body($msg_resp), true);
    $reply = $messages['data'][0]['content'][0]['text']['value'] ?? "❌ No response.";

    // ✅ If reply is JSON for WooCommerce request → execute it
    $result = ai_execute_full_request($reply);
    if ($result !== null) {
        // Send API result back to Assistant
        wp_remote_post("https://api.openai.com/v1/threads/$thread_id/messages", [
            'headers' => [
                'Authorization' => "Bearer $api_key",
                'Content-Type'  => 'application/json',
                'OpenAI-Beta'   => 'assistants=v2'
            ],
            'body' => json_encode([
                "role" => "user",
                "content" => "Here is the API result (in JSON). Summarize this result and display it in a clean, human-readable table or list for the user. ALWAYS reply with a summary:\n" . json_encode($result)
            ])
        ]);

        // 🔥 Auto-start a new run so the Assistant replies immediately
        wp_remote_post("https://api.openai.com/v1/threads/$thread_id/runs", [
            'headers' => [
                'Authorization' => "Bearer $api_key",
                'Content-Type'  => 'application/json',
                'OpenAI-Beta'   => 'assistants=v2'
            ],
            'body' => json_encode([
                "assistant_id" => $assistant_id
            ])
        ]);

        return "✅ API call executed. Result: " . json_encode($result);
    }

    ai_log_conversation($user_id, $task, $reply);
    return $reply;
}

?>
